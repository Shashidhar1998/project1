package com.pojo;


public class reportData {
	
	private int id;
	private String hospital_id;
	private String UserID;
	private String patientname;
	private String doctorid;
	private String doctor_name;
	private String disease;
	private String prescriptionprovided;
	private String date;
	private String slots;

	
	private String doctor_qualification;
	private String doctor_speciality;
	private String doctor_email;
	private String doctor_mobileno;

	private String hosiptal_name,hosiptal_address1,hosiptal_address2,hosiptal_state,hosiptal_city,hosiptal_pin;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHospital_id() {
		return hospital_id;
	}

	public void setHospital_id(String hospital_id) {
		this.hospital_id = hospital_id;
	}

	public String getUserID() {
		return UserID;
	}

	public void setUserID(String userID) {
		UserID = userID;
	}

	public String getPatientname() {
		return patientname;
	}

	public void setPatientname(String patientname) {
		this.patientname = patientname;
	}

	public String getDoctorid() {
		return doctorid;
	}

	public void setDoctorid(String doctorid) {
		this.doctorid = doctorid;
	}

	public String getDoctor_name() {
		return doctor_name;
	}

	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}

	public String getDisease() {
		return disease;
	}

	public void setDisease(String disease) {
		this.disease = disease;
	}

	public String getPrescriptionprovided() {
		return prescriptionprovided;
	}

	public void setPrescriptionprovided(String prescriptionprovided) {
		this.prescriptionprovided = prescriptionprovided;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getSlots() {
		return slots;
	}

	public void setSlots(String slots) {
		this.slots = slots;
	}

	public String getDoctor_qualification() {
		return doctor_qualification;
	}

	public void setDoctor_qualification(String doctor_qualification) {
		this.doctor_qualification = doctor_qualification;
	}

	public String getDoctor_speciality() {
		return doctor_speciality;
	}

	public void setDoctor_speciality(String doctor_speciality) {
		this.doctor_speciality = doctor_speciality;
	}

	public String getDoctor_email() {
		return doctor_email;
	}

	public void setDoctor_email(String doctor_email) {
		this.doctor_email = doctor_email;
	}

	public String getDoctor_mobileno() {
		return doctor_mobileno;
	}

	public void setDoctor_mobileno(String doctor_mobileno) {
		this.doctor_mobileno = doctor_mobileno;
	}

	public String getHosiptal_name() {
		return hosiptal_name;
	}

	public void setHosiptal_name(String hosiptal_name) {
		this.hosiptal_name = hosiptal_name;
	}

	public String getHosiptal_address1() {
		return hosiptal_address1;
	}

	public void setHosiptal_address1(String hosiptal_address1) {
		this.hosiptal_address1 = hosiptal_address1;
	}

	public String getHosiptal_address2() {
		return hosiptal_address2;
	}

	public void setHosiptal_address2(String hosiptal_address2) {
		this.hosiptal_address2 = hosiptal_address2;
	}

	public String getHosiptal_state() {
		return hosiptal_state;
	}

	public void setHosiptal_state(String hosiptal_state) {
		this.hosiptal_state = hosiptal_state;
	}

	public String getHosiptal_city() {
		return hosiptal_city;
	}

	public void setHosiptal_city(String hosiptal_city) {
		this.hosiptal_city = hosiptal_city;
	}

	public String getHosiptal_pin() {
		return hosiptal_pin;
	}

	public void setHosiptal_pin(String hosiptal_pin) {
		this.hosiptal_pin = hosiptal_pin;
	}	
	

}
