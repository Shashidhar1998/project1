package com.pojo;

public class weeklySchedule {
private String doctorname,date,countOfSlots;

public String getDoctorname() {
	return doctorname;
}

public void setDoctorname(String doctorname) {
	this.doctorname = doctorname;
}

public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public String getCountOfSlots() {
	return countOfSlots;
}

public void setCountOfSlots(String countOfSlots) {
	this.countOfSlots = countOfSlots;
}
}
